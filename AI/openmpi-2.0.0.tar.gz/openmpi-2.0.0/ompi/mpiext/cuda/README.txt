# Copyright (c) 2015      NVIDIA, Inc.  All rights reserved.

$COPYRIGHT$

Rolf vandeVaart


This extension provides a macro for compile time check of CUDA aware support.
It also provides a function for runtime check of CUDA aware support.

See MPIX_Query_cuda_support(3) for more details.
